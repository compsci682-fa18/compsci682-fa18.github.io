wget "http://supermoe.cs.umass.edu/682/asgns/squeezenet_tf.zip"
unzip squeezenet_tf.zip
rm squeezenet_tf.zip
